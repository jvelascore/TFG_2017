#include "bsp.h"
#include "mrfi.h"
#include "nwk_types.h"
#include "nwk_api.h"
#include "bsp_leds.h"
#include "bsp_buttons.h"
#include "nwk_pll.h"

//#include "PGN_protocol.h"

#include "bsp_sensors.h"
#include "bsp_digio.h"

static void linkTo(void);

void toggleLED(uint8_t);

/* Defines by pgn_protocol*/
/* 
 * ======== PGN_protocol.h ========
 */
#ifndef _PGN_PROTOCOL_H_
#define _PGN_PROTOCOL_H_

/*----------------------------------------------------------------------------+
 | Global defines                                                         |
 +----------------------------------------------------------------------------*/
#define FALSE                         0
#define TRUE                          1
#define PGN_ID                        0xAA
#define EOF_1                         0x0D
#define EOF_2                         0x0A
#define EOF                           0x0D0A
#define TIMEOUT_UART                  1000        // For a timeout of 50 ms, SMCLK=8MHz -> 80 = 8MHz/(2*0.050)

#define sLinkAP                       0x00  /*  AP Link ID*/

/*----------------------------------------------------------------------------+
 | Code BYTE 1                                                         |
 +----------------------------------------------------------------------------*/
#define REQUEST_FRAME         0x10          // Request frame from smartphone to PGN
#define RESPONSE_FRAME        0x08          // Response frame from PGN to smartphone
#define NUF_FRAME             0x04          // NUF frame from PGN to smartphone
#define ACK_FRAME             0x02          // ACK frame from smartphone to PGN

/*----------------------------------------------------------------------------+
 | Code BYTE 2   Peticiones del m�vil a la red (y sus respuestas)      |
 +----------------------------------------------------------------------------*/
//manejo de la red
#define GET_NODE_LIST         0x01
#define GET_NUM_NODES         0x02
#define GET_ED_ID             0x04
//sensores
#define GET_TEMPERATURE       0x08
#define GET_HUMIDITY          0x09
//leds
#define CLEAR_LED             0x10
#define SET_LED               0x11
#define TOGGLE_LED            0x12          
#define SET_ALL_LEDS          0x13
#define CLEAR_ALL_LEDS        0x14 
#define TOGGLE_ALL_LEDS       0x15

/*----------------------------------------------------------------------------+
 | Code BYTE 2   Mensajes NUF de la red al m�vil                       |
 +----------------------------------------------------------------------------*/
//manejo de la red
#define NUF_NEW_NODE          0x01
//sensores
#define NUF_UPDATE_TEMP       0x08
#define NUF_UPDATE_HUM        0x09

/*----------------------------------------------------------------------------+
 | DataPayload   Mensaje payload                                       |
 +----------------------------------------------------------------------------*/
#define CLEAR_LED_1           0x01
#define CLEAR_LED_2           0x02
#define SET_LED_1             0x01
#define SET_LED_2             0x02
#define TOGGLE_LED_1          0x01
#define TOGGLE_LED_2          0x02

#endif  
/*
 * _PGN_PROTOCOL_H_
 *------------------------ Nothing Below This Line --------------------------
 */



#define NUMBER_OF_SENSORS 3 //Number of sensors the node has
#define REST_BYTES 2  // command + num sensors

//static uint8_t tx_buf_rf[NUM_CONNECTIONS];
static uint8_t tx_buf_rf[10];
static uint8_t byteCountRf = 0;

/*Function headers by Lucanu*/

void initNode(uint8_t *description);
void rf_processMessage(uint8_t * code, uint8_t length);
void rf_createMessage(uint8_t code, uint8_t *data, uint8_t datalength);
//void processReceivedFrameRf(uint8_t * buf, uint8_t len)

static uint8_t description[NUMBER_OF_SENSORS + REST_BYTES];

/* Global variables by Lucanu*/

static uint8_t rf_txMessage[MAX_APP_PAYLOAD];


/* Callback handler */
static uint8_t sRxCallback(linkID_t);

static volatile uint8_t  sPeerFrameSem = 0;
static          linkID_t sLinkID1 = 0;  /*  Access Point Link ID*/
//static          linkID_t sLinkID1 = 1;  /*  Access Point Link ID*/
static volatile uint8_t  sSemaphore = 0;
static volatile uint8_t  nameED = 0xB2; /* Nombre del nodo*/

#define SPIN_ABOUT_A_SECOND   NWK_DELAY(1000)
#define SPIN_ABOUT_A_QUARTER_SECOND   NWK_DELAY(250)

/* How many times to try a Tx and miss an acknowledge before doing a scan */
#define MISSES_IN_A_ROW  2

void main (void)
{
  BSP_Init();
  /*  Initialize node's description */
//  initNode(description);

  /* If an on-the-fly device address is generated it must be done before the
   * call to SMPL_Init(). If the address is set here the ROM value will not
   * be used. If SMPL_Init() runs before this IOCTL is used the IOCTL call
   * will not take effect. One shot only. The IOCTL call below is conformal.
   */
#ifdef I_WANT_TO_CHANGE_DEFAULT_ROM_DEVICE_ADDRESS_PSEUDO_CODE
  {
    addr_t lAddr;

    createRandomAddress(&lAddr);
    SMPL_Ioctl(IOCTL_OBJ_ADDR, IOCTL_ACT_SET, &lAddr);
  }
#endif /* I_WANT_TO_CHANGE_DEFAULT_ROM_DEVICE_ADDRESS_PSEUDO_CODE */

  /* Keep trying to join (a side effect of successful initialization) until
   * successful. Toggle LEDS to indicate that joining has not occurred.
   */
  while (SMPL_SUCCESS != SMPL_Init(sRxCallback))
  {
    toggleLED(1);
    toggleLED(2);
    SPIN_ABOUT_A_SECOND; /* calls nwk_pllBackgrounder for us */
  }

  /* LEDs on solid to indicate successful join. */
  if (!BSP_LED2_IS_ON())
  {
    toggleLED(2);
  }
  if (!BSP_LED1_IS_ON())
  {
    toggleLED(1);
  }


  /* Unconditional link to AP which is listening due to successful join. */
  linkTo();

  while (1)
    FHSS_ACTIVE( nwk_pllBackgrounder( false ) );
}



static void linkTo()
{


  /* Keep trying to link... */
  while (SMPL_SUCCESS != SMPL_Link(&sLinkID1))
  {
    toggleLED(1);
    toggleLED(2);
    SPIN_ABOUT_A_SECOND; /* calls nwk_pllBackgrounder for us */
  }

  /* we're linked. turn off red LED. received messages will toggle the green LED. */
  if (BSP_LED2_IS_ON())
  {
    toggleLED(2);
  }
  if (!BSP_LED1_IS_ON())
  {
    toggleLED(1);
  }

  /* turn on RX. default is RX off. */
  SMPL_Ioctl( IOCTL_OBJ_RADIO, IOCTL_ACT_RADIO_RXON, 0);


  while (1)
  {

  if(sSemaphore>0){

    sSemaphore--;
//    rf_processMessage(sSemaphore,1);
    sSemaphore = 0;

    }
    
  }
}


void toggleLED(uint8_t which)
{
  if (1 == which)
  {
    BSP_TOGGLE_LED1();
  }
  else if (2 == which)
  {
    BSP_TOGGLE_LED2();
  }
  return;
}


/* handle received messages */
static uint8_t sRxCallback(linkID_t port)
{
  uint8_t msg[MAX_APP_PAYLOAD], len;
  /* is the callback for the link ID we want to handle? */
  if (port == sLinkID1)
  {


    /* yes. go get the frame. we know this call will succeed. */
     if((SMPL_SUCCESS == SMPL_Receive(sLinkID1, msg, &len)) && len){
     
      /*  Process the received frame, which is only a 1-byte command...  */
      /*  Store this byte in the flag  */
       rf_processMessage(msg,len);
      sSemaphore = msg[0]+1;    
      
    }

    /* Post to the semaphore to let application know so it processes 
     * and sends the reply
     */




    return 1;
  }
  return 0;
}
/*
Initialize the node
*/

void initNode(uint8_t *des){
  
  // Create a vector with the type of sensors the node has. In this case:
  des[0] = 0; // command code. This is a response to command code "0" so put this command code to identify it
  des[1] = NUMBER_OF_SENSORS; // N� sensors
  des[2] = 1; // temp
  des[3] = 2; // humidity
  des[4] = 3; // wind
}

/*
Create a message to send over RF
*/

void rf_createMessage(uint8_t code, uint8_t *data, uint8_t datalength){
  int i = 0;
  rf_txMessage[0] = code;
  for (i = 0; i < datalength; i++){
  rf_txMessage[i+1] = data[i];
  }
  SMPL_Send(sLinkID1, rf_txMessage, datalength+1);

}

static void rf_processMessage( uint8_t *msg, uint8_t len)
{
  linkID_t lid = sLinkID1;
  uint8_t i;
  int temperature, humidity;
  uint8_t temp_data[2];
  uint8_t hum_data[2];

  switch(msg[3])
    {
      
       case  GET_ED_ID:
                 byteCountRf  = len+1;
                 tx_buf_rf[0] = byteCountRf - 3;
                 tx_buf_rf[1] = lid;
                 tx_buf_rf[2] = RESPONSE_FRAME;
                 tx_buf_rf[3] = GET_ED_ID;
                 tx_buf_rf[4] = nameED;
                 tx_buf_rf[5] = 0x0D;
                 tx_buf_rf[6] = 0x0A;
                 SMPL_Send(lid, tx_buf_rf, byteCountRf);
                 byteCountRf = 0;
       break;
       
       case  GET_TEMPERATURE:
                temperature = SHT75_medirTemperatura();
                temp_data[0] = (temperature>>8) & 0xff; // most significant part first
                temp_data[1] = temperature & 0xff;
                byteCountRf  = len+2;
                tx_buf_rf[0] = byteCountRf - 3;
                tx_buf_rf[1] = lid;
                tx_buf_rf[2] = RESPONSE_FRAME;
                tx_buf_rf[3] = GET_TEMPERATURE;
                tx_buf_rf[4] = temp_data[0];
                tx_buf_rf[5] = temp_data[1];
                tx_buf_rf[6] = 0x0D;
                tx_buf_rf[7] = 0x0A;
                SMPL_Send(lid, tx_buf_rf, byteCountRf);
                byteCountRf = 0;
       break;
       
       case  GET_HUMIDITY:
                humidity = SHT75_medirHumedad();
                hum_data[0] = (humidity>>8) & 0xff; // most significant part first
                hum_data[1] = humidity & 0xff;
                byteCountRf  = len+2;
                tx_buf_rf[0] = byteCountRf - 3;
                tx_buf_rf[1] = lid;
                tx_buf_rf[2] = RESPONSE_FRAME;
                tx_buf_rf[3] = GET_TEMPERATURE;
                tx_buf_rf[4] = hum_data[0];
                tx_buf_rf[5] = hum_data[1];
                tx_buf_rf[6] = 0x0D;
                tx_buf_rf[7] = 0x0A;
                SMPL_Send(lid, tx_buf_rf, byteCountRf);
                byteCountRf = 0;
       break;

         
        case  TOGGLE_LED:
             
           byteCountRf  = len-1;
                 tx_buf_rf[0] = byteCountRf - 3;
                 tx_buf_rf[1] = lid;
                 tx_buf_rf[2] = RESPONSE_FRAME;
                 tx_buf_rf[3] = TOGGLE_LED;
                 tx_buf_rf[4] = 0x0D;
                 tx_buf_rf[5] = 0x0A;
                 SMPL_Send(lid, tx_buf_rf, byteCountRf);
                 byteCountRf = 0;
          
              switch(msg[4])
              {
              case TOGGLE_LED_1:
                  toggleLED(1);
                break;
              case TOGGLE_LED_2:
                  toggleLED(2);
                break;
              default:
                break;        
              }
         break;
         
         case  CLEAR_LED:
           
           byteCountRf  = len-1;
                 tx_buf_rf[0] = byteCountRf - 3;
                 tx_buf_rf[1] = lid;
                 tx_buf_rf[2] = RESPONSE_FRAME;
                 tx_buf_rf[3] = CLEAR_LED;
                 tx_buf_rf[4] = 0x0D;
                 tx_buf_rf[5] = 0x0A;
                 SMPL_Send(lid, tx_buf_rf, byteCountRf);
                 byteCountRf = 0;
             
              switch(msg[4])
              {
              case CLEAR_LED_1:
                   if (BSP_LED1_IS_ON())
                      {
                      toggleLED(1);
                      }
                break;
              case CLEAR_LED_2:
                  if (BSP_LED2_IS_ON())
                      {
                      toggleLED(2);
                      }
                break;
              default:
                break;
                
                
               }
         break;
         
         case  SET_LED:
           
           byteCountRf  = len-1;
                 tx_buf_rf[0] = byteCountRf - 3;
                 tx_buf_rf[1] = lid;
                 tx_buf_rf[2] = RESPONSE_FRAME;
                 tx_buf_rf[3] = SET_LED;
                 tx_buf_rf[4] = 0x0D;
                 tx_buf_rf[5] = 0x0A;
                 SMPL_Send(lid, tx_buf_rf, byteCountRf);
                 byteCountRf = 0;
             
              switch(msg[4])
              {
              case SET_LED_1:
                   if (!BSP_LED1_IS_ON())
                      {
                      toggleLED(1);
                      }
                break;
              case SET_LED_2:
                  if (!BSP_LED2_IS_ON())
                      {
                      toggleLED(2);
                      }
                break;
              default:
                break;
               }
         break;
         
         case  SET_ALL_LEDS:
              if (!BSP_LED1_IS_ON())
                 {
                 toggleLED(1);
                 }
              if (!BSP_LED2_IS_ON())
                 {
                 toggleLED(2);
                 }
              byteCountRf  = len;
                 tx_buf_rf[0] = byteCountRf - 3;
                 tx_buf_rf[1] = lid;
                 tx_buf_rf[2] = RESPONSE_FRAME;
                 tx_buf_rf[3] = SET_ALL_LEDS;
                 tx_buf_rf[4] = 0x0D;
                 tx_buf_rf[5] = 0x0A;
                 SMPL_Send(lid, tx_buf_rf, byteCountRf);
                 byteCountRf = 0;
         break;
         
         case  CLEAR_ALL_LEDS:
              if (BSP_LED1_IS_ON())
                 {
                 toggleLED(1);
                 }
              if (BSP_LED2_IS_ON())
                 {
                 toggleLED(2);
                 }
              byteCountRf  = len;
                 tx_buf_rf[0] = byteCountRf - 3;
                 tx_buf_rf[1] = lid;
                 tx_buf_rf[2] = RESPONSE_FRAME;
                 tx_buf_rf[3] = CLEAR_ALL_LEDS;
                 tx_buf_rf[4] = 0x0D;
                 tx_buf_rf[5] = 0x0A;
                 SMPL_Send(lid, tx_buf_rf, byteCountRf);
                 byteCountRf = 0;
         break;
         
         case  TOGGLE_ALL_LEDS:
                 toggleLED(1);
                 toggleLED(2);
                 byteCountRf  = len;
                 tx_buf_rf[0] = byteCountRf - 3;
                 tx_buf_rf[1] = lid;
                 tx_buf_rf[2] = RESPONSE_FRAME;
                 tx_buf_rf[3] = TOGGLE_ALL_LEDS;
                 tx_buf_rf[4] = 0x0D;
                 tx_buf_rf[5] = 0x0A;
                 SMPL_Send(lid, tx_buf_rf, byteCountRf);
                 byteCountRf = 0;
         break;
         
            
          default:
            break;
//      }
           
         
    }
}


///*----------------------------------------------------------------------------
// *  Demo Application for SimpliciTI
// *
// *  L. Friedman
// *  Texas Instruments, Inc.
// *---------------------------------------------------------------------------- */
//
///**********************************************************************************************
//  Copyright 2007-2008 Texas Instruments Incorporated. All rights reserved.
//
//  IMPORTANT: Your use of this Software is limited to those specific rights granted under
//  the terms of a software license agreement between the user who downloaded the software,
//  his/her employer (which must be your employer) and Texas Instruments Incorporated (the
//  "License"). You may not use this Software unless you agree to abide by the terms of the
//  License. The License limits your use, and you acknowledge, that the Software may not be
//  modified, copied or distributed unless embedded on a Texas Instruments microcontroller
//  or used solely and exclusively in conjunction with a Texas Instruments radio frequency
//  transceiver, which is integrated into your product. Other than for the foregoing purpose,
//  you may not use, reproduce, copy, prepare derivative works of, modify, distribute,
//  perform, display or sell this Software and/or its documentation for any purpose.
//
//  YOU FURTHER ACKNOWLEDGE AND AGREE THAT THE SOFTWARE AND DOCUMENTATION ARE PROVIDED �AS IS�
//  WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY
//  WARRANTY OF MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
//  IN NO EVENT SHALL TEXAS INSTRUMENTS OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER CONTRACT,
//  NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR OTHER LEGAL EQUITABLE
//  THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES INCLUDING BUT NOT LIMITED TO ANY
//  INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST
//  DATA, COST OF PROCUREMENT OF SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY
//  THIRD PARTIES (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
//
//  Should you have any questions regarding your right to use this Software,
//  contact Texas Instruments Incorporated at www.TI.com.
//**************************************************************************************************/
//
//#include "bsp.h"
//#include "mrfi.h"
//#include "nwk_types.h"
//#include "nwk_api.h"
//#include "bsp_leds.h"
//#include "bsp_buttons.h"
//#include "nwk_pll.h"
//
//#include "bsp_sensors.h"
//#include "bsp_digio.h"
//
//static void linkTo(void);
//
//void toggleLED(uint8_t);
//
///* Defines by Lucanu*/
//
//#define NUMBER_OF_SENSORS 3 //Number of sensors the node has
//#define REST_BYTES 2  // command + num sensors
//
///*Function headers by Lucanu*/
//
//void initNode(uint8_t *description);
//void rf_processMessage(uint8_t code, uint8_t length);
//void rf_createMessage(uint8_t code, uint8_t *data, uint8_t datalength);
//
//static uint8_t description[NUMBER_OF_SENSORS + REST_BYTES];
//
///* Global variables by Lucanu*/
//
//static uint8_t rf_txMessage[MAX_APP_PAYLOAD];
//
//
///* Callback handler */
//static uint8_t sRxCallback(linkID_t);
//
//static volatile uint8_t  sPeerFrameSem = 0;
//static          linkID_t sLinkID1 = 0;  /*  Access Point Link ID*/
//static volatile uint8_t  sSemaphore = 0;
//
//#define SPIN_ABOUT_A_SECOND   NWK_DELAY(1000)
//#define SPIN_ABOUT_A_QUARTER_SECOND   NWK_DELAY(250)
//
///* How many times to try a Tx and miss an acknowledge before doing a scan */
//#define MISSES_IN_A_ROW  2
//
//void main (void)
//{
//  BSP_Init();
//  /*  Initialize node's description */
//  initNode(description);
//
//  /* If an on-the-fly device address is generated it must be done before the
//   * call to SMPL_Init(). If the address is set here the ROM value will not
//   * be used. If SMPL_Init() runs before this IOCTL is used the IOCTL call
//   * will not take effect. One shot only. The IOCTL call below is conformal.
//   */
//#ifdef I_WANT_TO_CHANGE_DEFAULT_ROM_DEVICE_ADDRESS_PSEUDO_CODE
//  {
//    addr_t lAddr;
//
//    createRandomAddress(&lAddr);
//    SMPL_Ioctl(IOCTL_OBJ_ADDR, IOCTL_ACT_SET, &lAddr);
//  }
//#endif /* I_WANT_TO_CHANGE_DEFAULT_ROM_DEVICE_ADDRESS_PSEUDO_CODE */
//
//  /* Keep trying to join (a side effect of successful initialization) until
//   * successful. Toggle LEDS to indicate that joining has not occurred.
//   */
//  while (SMPL_SUCCESS != SMPL_Init(sRxCallback))
//  {
//    toggleLED(1);
//    toggleLED(2);
//    SPIN_ABOUT_A_SECOND; /* calls nwk_pllBackgrounder for us */
//  }
//
//  /* LEDs on solid to indicate successful join. */
//  if (!BSP_LED2_IS_ON())
//  {
//    toggleLED(2);
//  }
//  if (!BSP_LED1_IS_ON())
//  {
//    toggleLED(1);
//  }
//
//
//  /* Unconditional link to AP which is listening due to successful join. */
//  linkTo();
//
//  while (1)
//    FHSS_ACTIVE( nwk_pllBackgrounder( false ) );
//}
//
//
//
//static void linkTo()
//{
//
//
//  /* Keep trying to link... */
//  while (SMPL_SUCCESS != SMPL_Link(&sLinkID1))
//  {
//    toggleLED(1);
//    toggleLED(2);
//    SPIN_ABOUT_A_SECOND; /* calls nwk_pllBackgrounder for us */
//  }
//
//  /* we're linked. turn off red LED. received messages will toggle the green LED. */
//  if (BSP_LED2_IS_ON())
//  {
//    toggleLED(2);
//  }
//  if (!BSP_LED1_IS_ON())
//  {
//    toggleLED(1);
//  }
//
//  /* turn on RX. default is RX off. */
//  SMPL_Ioctl( IOCTL_OBJ_RADIO, IOCTL_ACT_RADIO_RXON, 0);
//
//
//  while (1)
//  {
//
//  if(sSemaphore>0){
//
//    sSemaphore--;
//    rf_processMessage(sSemaphore,1);
//    sSemaphore = 0;
//
//    }
//
//    
//  }
//}
//
//
//void toggleLED(uint8_t which)
//{
//  if (1 == which)
//  {
//    BSP_TOGGLE_LED1();
//  }
//  else if (2 == which)
//  {
//    BSP_TOGGLE_LED2();
//  }
//  return;
//}
//
//
///* handle received messages */
//static uint8_t sRxCallback(linkID_t port)
//{
//  uint8_t msg[MAX_APP_PAYLOAD], len;
//  /* is the callback for the link ID we want to handle? */
//  if (port == sLinkID1)
//  {
//
//
//    /* yes. go get the frame. we know this call will succeed. */
//     if((SMPL_SUCCESS == SMPL_Receive(sLinkID1, msg, &len)) && len){
//     
//      /*  Process the received frame, which is only a 1-byte command...  */
//      /*  Store this byte in the flag  */
//      sSemaphore = msg[0]+1;    
//      
//    }
//
//    /* Post to the semaphore to let application know so it processes 
//     * and sends the reply
//     */
//
//
//
//
//    return 1;
//  }
//  return 0;
//}
///*
//Initialize the node
//*/
//
//void initNode(uint8_t *des){
//  
//  // Create a vector with the type of sensors the node has. In this case:
//  des[0] = 0; // command code. This is a response to command code "0" so put this command code to identify it
//  des[1] = NUMBER_OF_SENSORS; // N� sensors
//  des[2] = 1; // temp
//  des[3] = 2; // humidity
//  des[4] = 3; // wind
//}
//
///*
//Create a message to send over RF
//*/
//
//void rf_createMessage(uint8_t code, uint8_t *data, uint8_t datalength){
//  int i = 0;
//  rf_txMessage[0] = code;
//  for (i = 0; i < datalength; i++){
//  rf_txMessage[i+1] = data[i];
//  }
//  SMPL_Send(sLinkID1, rf_txMessage, datalength+1);
//
//}
//
///*
//Process the message received from the AP
//*/
//
//void rf_processMessage(uint8_t code, uint8_t len){
//  int temp, humid;
//  uint8_t data[2];
//
//  switch(code){
//
//  case 0x0: // get Descriptor
//    SMPL_Send(sLinkID1, description, sizeof(description));
//      /*  Toggle LED in the message */
//
//    if (!BSP_LED2_IS_ON())
//    {
//      toggleLED(2);
//    }
//
//    break;
//    
//  case 0x1:
//    temp = SHT75_medirTemperatura();
//    data[0] = (temp>>8) & 0xff; // most significant part first
//    data[1] = temp & 0xff;
//    // send the temperature
//    rf_createMessage(code, data, sizeof(data));
//    break;
//    
//  case 0x2:
//    humid = SHT75_medirHumedad();
//    data[0] = (humid>>8) & 0xff; // most significant part first
//    data[1] = humid & 0xff;
//   // send the humidity
//    rf_createMessage(code, data, sizeof(data));
//    break;
//    
//  case 0x3:   
//    // wSpeed = readWindSpeed();
//    // send the wind speed
//    //rf_createMessage(messageCode, &data, sizeof(data));
//    break;
//    
//  case 0x4:
//    //rf_createMessage(messageCode, &data, sizeof(data));
//    break;
//
//  case 0x0A:
//
//    toggleLED(1);
//
//    break;
//
//  case 0x0B:
//    
//    toggleLED(2);
//
//    break;
//
//    
//  default:
//
//    break;
//    
//  }
//
//}