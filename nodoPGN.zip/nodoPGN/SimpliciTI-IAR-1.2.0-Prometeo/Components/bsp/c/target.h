/* target.h target defines header for C/C++ library */
/* Copyright 2009-2010 IAR Systems AB. */

#ifndef _SYSTEM_BUILD
  #pragma system_include
#endif

/* Add customization defines for the library here */
