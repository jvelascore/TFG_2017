/* xtls.h internal header */
/* Copyright 2003-2010 IAR Systems AB. */
#ifndef _XTLS
#define _XTLS

#ifndef _SYSTEM_BUILD
  #pragma system_include
#endif

#include <xmtx.h>

/* We need to turn off this warning */
#pragma diag_suppress = Pe076

_C_LIB_DECL
__ATTRIBUTES int __iar_Atthreadexit(void (*)(void));
__ATTRIBUTES void __iar_Destroytls(void);

#define _IMPLICIT_EXTERN

#if _COMPILER_TLS
  #define _XTLS_QUAL    _TLS_QUAL
#else /* _COMPILER_TLS */
  #define _XTLS_QUAL
#endif /* _COMPILER_TLS */

#if _GLOBAL_LOCALE
  #define _TLS_LOCK(lock)       __iar_Locksyslock(lock)
  #define _TLS_UNLOCK(lock)     __iar_Unlocksyslock(lock)
#else /* _GLOBAL_LOCALE */
  #define _TLS_LOCK(lock)       (void)0
  #define _TLS_UNLOCK(lock)     (void)0
#endif /* _GLOBAL_LOCALE */

#define _XTLS_DTOR(name)        __iar_Tls_dtor_ ## name
#define _XTLS_GET(name)         __iar_Tls_get_ ## name
#define _XTLS_INIT(name)        __iar_Tls_init_ ## name
#define _XTLS_KEY(name)         __iar_Tls_key_ ## name
#define _XTLS_ONCE(name)        __iar_Tls_once_ ## name
#define _XTLS_REG(name)         __iar_Tls_reg_ ## name
#define _XTLS_SETUP(name)       __iar_Tls_setup_ ## name
#define _XTLS_SETUPX(name)      __iar_Tls_setupx_ ## name

#if _COMPILER_TLS
  #define _CLEANUP(x)   __iar_Atthreadexit(x)
#else /* _COMPILER_TLS */
  #define _CLEANUP(x)   __iar_Atexit(x)
#endif /* _COMPILER_TLS */

#ifndef _DLIB_THREAD_MACRO_SETUP_DONE
  #define _DLIB_THREAD_MACRO_SETUP_DONE 0
#endif /* _DLIB_THREAD_MACRO_SETUP_DONE */

#if _DLIB_THREAD_MACRO_SETUP_DONE
#else /*  _DLIB_THREAD_MACRO_SETUP_DONE */

#if !_MULTI_THREAD || _GLOBAL_LOCALE || _COMPILER_TLS

  #define _TLS_DATA_DECL(type, name) \
        extern int (*_XTLS_SETUP(name))(void); \
        extern _XTLS_QUAL type name

  #define _TLS_DEFINE_INIT(scope, type, name) \
        scope _XTLS_QUAL type name

  #define _TLS_DEFINE_NO_INIT(scope, type, name) \
        scope int (* _XTLS_SETUP(name))(void) = 0

  #define _TLS_DATA_DEF(scope, type, name, init) \
        _TLS_DEFINE_INIT(scope, type, name) = init; \
        _TLS_DEFINE_NO_INIT(scope, type, name)

  #define _TLS_DEFINE_INIT_DT(scope, type, name) \
        _TLS_DEFINE_INIT(scope, type, name)

  #define _TLS_DEFINE_NO_INIT_DT(scope, type, name, dtor) \
        _DLIB_DATA_ATTR static _Once_t _XTLS_ONCE(name) = _ONCE_T_INIT; \
        static void _XTLS_DTOR(name)(void) \
        { \
        dtor(&(name)); \
        } \
        static void _XTLS_REG(name)(void) \
        { \
        _CLEANUP(_XTLS_DTOR(name)); \
        } \
        static int _XTLS_SETUPX(name)(void) \
        { \
        _Once(&_XTLS_ONCE(name), _XTLS_REG(name)); \
        return 1; \
        } \
        scope int (*_XTLS_SETUP(name))(void) = _XTLS_SETUPX(name)

  #define _TLS_DATA_DEF_DT(scope, type, name, init, dtor) \
        _TLS_DEFINE_INIT_DT(scope, type, name) = init; \
        _TLS_DEFINE_NO_INIT_DT(scope, type, name, dtor)

  /* IAR added type parameter */
  #define _TLS_DATA_PTR(type, name) \
        ((_XTLS_SETUP(name) && _XTLS_SETUP(name)()), (&(name)))

  #define _TLS_ARR_DECL(type, name) \
        extern type name[]

  #define _XTLS_ARR_DEF_INIT(scope, type, name, elts) \
        scope _XTLS_QUAL type name[elts]

  #define _TLS_ARR_DEF(scope, type, name, elts) \
        _XTLS_ARR_DEF_INIT(scope, type, name, elts); \
        _TLS_DEFINE_NO_INIT(scope, type, name)

  #define _TLS_ARR_DEF_DT(scope, type, name, elts, dtor) \
        _XTLS_ARR_DEF_INIT(scope, type, name, elts); \
        _TLS_DEFINE_NO_INIT_DT(scope, type, name, dtor)

  /* IAR added type parameter */
  #define _TLS_ARR(type, name) \
        ((_XTLS_SETUP(name) && _XTLS_SETUP(name)()), (&(name[0])))

#else /* !_MULTI_THREAD || _GLOBAL_LOCALE || _COMPILER_TLS */

  #define _TLS_DATA_DECL(type, name) \
        extern type *_XTLS_GET(name)(void)

  #define _TLS_DEFINE_INIT(scope, type, name) \
        _DLIB_CONST_ATTR static type const _XTLS_INIT(name)

  #define _XTLS_DEFINE_NO_INIT(scope, type, name, elts, dtor) \
        _DLIB_DATA_ATTR static _Once_t _XTLS_ONCE(name) = _ONCE_T_INIT; \
        static __iar_Tlskey_t _XTLS_KEY(name); \
        static void _XTLS_SETUP(name)(void) \
        { \
        __iar_Tlsalloc(&_XTLS_KEY(name), dtor); \
        } \
        scope type *_XTLS_GET(name)(void); \
        scope type *_XTLS_GET(name)(void) \
        { \
        type *_Ptr; \
        _Once(&_XTLS_ONCE(name), _XTLS_SETUP(name)); \
        if ((_Ptr = (type *)__iar_Tlsget(_XTLS_KEY(name))) != 0) \
                ; \
        else if ((_Ptr = (type *)calloc(elts, sizeof(type))) == 0) \
                ; \
        else if (__iar_Tlsset(_XTLS_KEY(name), (void*)_Ptr) != 0) \
                free((void*)_Ptr), _Ptr = 0; \
        else \
                *_Ptr = _XTLS_INIT(name); \
        return _Ptr; \
        } \
        extern int _TLS_Dummy

  #define _TLS_DEFINE_NO_INIT(scope, type, name) \
        _XTLS_DEFINE_NO_INIT(scope, type, name, 1, free)

  #define _TLS_DATA_DEF(scope, type, name, init) \
        _TLS_DEFINE_INIT(scope, type, name) = init; \
        _XTLS_DEFINE_NO_INIT(scope, type, name, 1, free)

  #define _TLS_DEFINE_INIT_DT(scope, type, name) \
        _TLS_DEFINE_INIT(scope, type, name)

  #define _XTLS_DEFINE_NO_INIT_DT(scope, type, name, elts, dtor) \
        static void _XTLS_DTOR(name)(void* _Ptr) \
        { \
        (dtor)(_Ptr); \
        free(_Ptr); \
        } \
        _XTLS_DEFINE_NO_INIT(scope, type, name, elts, _XTLS_DTOR(name))

  #define _TLS_DEFINE_NO_INIT_DT(scope, type, name, dtor) \
        _XTLS_DEFINE_NO_INIT_DT(scope, type, name, 1, dtor)

  #define _TLS_DATA_DEF_DT(scope, type, name, init, dtor) \
        _TLS_DEFINE_INIT_DT(scope, type, name) = init; \
        _TLS_DEFINE_NO_INIT_DT(scope, type, name, dtor)

  /* IAR added type parameter */
  #define _TLS_DATA_PTR(type, name) _XTLS_GET(name)()

  #define _TLS_ARR_DECL(type, name) \
        _TLS_DATA_DECL(type, name)

  #define _TLS_ARR_DEF(scope, type, name, elts) \
        _TLS_DEFINE_INIT(scope, type, name) = {0}; \
        _XTLS_DEFINE_NO_INIT(scope, type, name, elts, free)

  #define _TLS_ARR_DEF_DT(scope, type, name, elts, dtor) \
        _TLS_DEFINE_INIT(scope, type, name) = {0}; \
        _XTLS_DEFINE_NO_INIT_DT(scope, type, name, elts, dtor)

  /* IAR added type parameter */
  #define _TLS_ARR(type, name) \
        _XTLS_GET(name)()
#endif /* !_MULTI_THREAD || _GLOBAL_LOCALE || _COMPILER_TLS */
#endif /* _DLIB_THREAD_MACRO_SETUP_DONE */


_END_C_LIB_DECL
#endif /* _XTLS */

/*
 * Copyright (c) 1992-2009 by P.J. Plauger.  ALL RIGHTS RESERVED.
 * Consult your license regarding permissions and restrictions.
V5.04:0576 */
