// iomanip.h standard header -*-c++-*-
// Copyright 2009-2010 IAR Systems AB.
#ifndef _IOMANIP_H_
#define _IOMANIP_H_

#ifndef _SYSTEM_BUILD
  #pragma system_include
#endif

#include <iomanip>

 #if _HAS_NAMESPACE
using namespace std;
 #endif
#endif /* _IOMANIP_ */

/*
 * Copyright (c) 1992-2009 by P.J. Plauger.  ALL RIGHTS RESERVED.
 * Consult your license regarding permissions and restrictions.
V5.04:0576 */
