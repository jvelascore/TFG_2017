// iostream.h standard header -*-c++-*-
// Copyright 2009-2010 IAR Systems AB.
#ifndef _IOSTREAM_H_
#define _IOSTREAM_H_

#ifndef _SYSTEM_BUILD
  #pragma system_include
#endif

#include <iostream>

#if _HAS_NAMESPACE
  using namespace std;
#endif /* _HAS_NAMESPACE */
#endif /* _IOSTREAM_H_ */

/*
 * Copyright (c) 1992-2009 by P.J. Plauger.  ALL RIGHTS RESERVED.
 * Consult your license regarding permissions and restrictions.
V5.04:0576 */
