// strstream.h standard header -*-c++-*-
// Copyright 2009-2010 IAR Systems AB.
#ifndef _STRSTREAM_H_
#define _STRSTREAM_H_

#ifndef _SYSTEM_BUILD
  #pragma system_include
#endif

#include <strstream>

#if _HAS_NAMESPACE
  using namespace std;
#endif
#endif /* _FSTREAM_ */

/*
 * Copyright (c) 1992-2009 by P.J. Plauger.  ALL RIGHTS RESERVED.
 * Consult your license regarding permissions and restrictions.
V5.04:0576 */
